Ritsumeikan University has several international dormitories called
“International Houses” near each campus. Japanese students (bilingual Resident
Mentors) also live in the dormitory and help international student transition
to living in Japan.

  * [Kinugasa Campus](/lifecareer-e/dorm/kinugasa)
  * [Biwako-Kusatsu Campus](/lifecareer-e/dorm/bkc/)

Osaka Ibaraki Campus

  * [OIC International House](/lifecareer-e/dorm/oic)
  * [OIC Global House](/lifecareer-e/dorm/oic2)  

