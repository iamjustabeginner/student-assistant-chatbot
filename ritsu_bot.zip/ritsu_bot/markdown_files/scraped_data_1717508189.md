If the language proficiency test score can be checked online, please submit a
screenshot of the webpage first.  
In this case, please submit a page that shows your name and score.  
Once the original arrives at a later date, please submit a copy.

*For inquiries, please contact the study abroad staff at the International Center [＜Here＞](https://global.support.ritsumei.ac.jp/hc/en/requests/new?ticket_form_id=360006493753).

