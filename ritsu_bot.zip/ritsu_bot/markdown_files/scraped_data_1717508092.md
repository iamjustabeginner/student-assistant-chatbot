The university, as an institution accepting international students, must be
aware of the studies/research that students are conducting and their status of
residence, and as necessary must inform the Immigration Services Agency and
MEXT (the Ministry of Education, Culture, Sports, Science and Technology) of
this information.

It is vital that the university stay aware of each student's status of
residence, so that we are able to smoothly support them in the event that they
get involved in trouble.

When you extend or change your status of residence, take a leave of absence,
or when the university requests it, please submit your Residence Card as soon
as possible.

Please submit it using [this form](https://global.support.ritsumei.ac.jp/hc/en-us/requests/new?ticket_form_id=360006867793).

