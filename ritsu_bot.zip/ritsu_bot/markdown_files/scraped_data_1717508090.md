If the Government of Japan (Ministry of Justice, Ministry of Foreign Affairs,
etc) published important information, the university will notify you via this
FAQ site, manaba + R, e-mail, etc.

It is also important to check with the nearest Immigration services Agency
(Ministry of Justice) in Japan or the nearest Japanese embassy / consulate at
your home country.

The Immigration Services Agency provides an e-mail delivery service that
informs foreigners living in Japan of Japan's immigration procedures and
living support information.

If you register for the e-mail delivery service, you will receive important
notifications from the Immigration Services Agency on your mobile phone or
computer. Registration is free.

Please check the details from the following website and use it.

  
**Website:** [**Email Distribution Service of the Immigration Services Agency of Japan | Immigration Services Agency of Japan (isa.go.jp)**](https://www.isa.go.jp/en/about/pr/mail-service.html)

