Various qualification certificates (e.g., language scores, etc.) must be
submitted when applying for a study abroad program.  
Therefore, you will not be able to apply if you do not meet the application
requirements of the program at the time of application (i.e., your application
will not be qualified to be screened).

*For inquiries, please contact the study abroad staff at the International Center [＜Here＞](https://global.support.ritsumei.ac.jp/hc/en/requests/new?ticket_form_id=360006493753).

