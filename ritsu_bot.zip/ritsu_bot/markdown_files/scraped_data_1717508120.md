If you found out that you overpaid on tuition with the announcement of results
of the tuition reduction applications, you will be refunded or have the
difference subtracted from your next semester's payment. The timing for
refunds varies depending on the status of tuition payment, but a notification
of the refund procedure will be delivered at the latest during May of the year
after the student applied for the tuition reduction.

For inquiries about paying tuition, please contact the Office of Finance and
Accounting:  
Ritsumeikan University, Office of Finance and Accounting

  
<http://www.ritsumei.ac.jp/tuitionfees/>

TEL: 075-813-8164  
Hours: 9:00AM - 5:30PM  
(Closed Sat., Sun., and Holidays. )

