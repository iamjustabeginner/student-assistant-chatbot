For credit information for short-term and one-semester programs (available
only in Japanese), please check the ”単位授与科目一覧” posted on Application
Guidelines page of the Study Abroad Program website.

For long-term programs, please refer to the section "Grading, Credits" of each
program in the Application Guideline.

  
Application Guidelines:
<https://secure.ritsumei.ac.jp/students/studyabroad/students/guideline.html/>

*For inquiries, please contact the study abroad staff at the International Center [＜Here＞](https://global.support.ritsumei.ac.jp/hc/en/requests/new?ticket_form_id=360006493753).

