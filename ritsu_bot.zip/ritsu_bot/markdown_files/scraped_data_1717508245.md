# Makeup Examinations

A student who could not take a Final Examination due to an unavoidable reason (illness, bereavement leave, etc.) may be allowed to take makeup exams. In this case, the student needs to submit an application with the necessary certificates during the application period and complete the procedures. Please read "[Makeup Examinations: Schedule and Procedures](/file.jsp?id=483382)" and "[Application Procedures for Make-up Examination on CAMPUS WEB](http://www.ritsumei.ac.jp/pathways-future/makeup/exam/manual/for/students/en.pdf)" to learn about the procedures.
#### If the reason for not taking examinations is due to illness

If you are diagnosed as School Infectious Disease,please follow the procedures for reporting to [Medical Service Center](https://en.ritsumei.ac.jp/health/) as well.
#### If the reason for not taking examinations is to take a job examination

If the reason for not taking examinations is to take a job examination, please
check the following.

[Application for Makeup Examination when unable to take Final Examinations due to Job Examinations](/file.jsp?id=501721)  
[Verification of Participation in Job Examination](/file.jsp?id=499661)  
[Request for Issuance of Verification of Participation in Job Examination](/file.jsp?id=499654)
#### If final exams at Ritsumeikan University coincide with exams or classes
at other universities

If final exams at Ritsumeikan University coincide with exams or classes at
other universities (for the students taking the courses of the Consortium of
Universities in Kyoto/ Kan Biwako University Regional Consortium), students
are able to take make-up exams at Ritsumeikan University upon application.

[Measures to be taken for Makeup Examination when Final Examination at the university overlap with examinations and classes at other universities](/file.jsp?id=499663)  
[Consortium of Universities in Kyoto Certificate of Credit Transfer Course Attendance and Examination ](/file.jsp?id=499662)  
[Kan Biwako University Regional Consortium Certificate of Credit Transfer Course Attendance and Examination](/file.jsp?id=499672)
### For taking makeup examinations

  * ・Makeup examination schedule will be the same as the final examination schedule. (e.g. 1st period 9:30 - 10:30)  
As with the final examination schedule, please check dates and time for makeup
examinations on CAMPUS WEB.

  * ・Precautions when taking makeup examinations (All students must bring their student ID to take an exam. A student arriving more than 20 minutes late after the start of an exam will not be admitted to the examination room, etc.) are also the same as for final examinations.

For details, please check the [Final Examination page](/pathways-future/eng/examinations_grades/final_examinations.html).
For inquiries

Kinugasa: Gakujikan Hall 1F (Manabi Station)  
BKC: Prism House 1F (Manabi Station)  
OIC: Building A 1F AC Office (Manabi Station)

