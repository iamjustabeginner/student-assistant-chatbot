Application information sessions (Japanese only) are held one month to two
weeks before the application period for each study abroad program. We also
hold various seminars about studying abroad (Japanese only).  
Specific dates will be announced via manaba+R, notice boards at the
International Center, and the application guidelines for each program.

For students who are not fluent in Japanese to attend these sessions, please contact the International Center for further information[＜Here＞](mailto:ru-sa@st.ritsumei.ac.jp).
*For inquiries, please contact the study abroad staff at the International Center [＜Here＞](https://global.support.ritsumei.ac.jp/hc/en/requests/new?ticket_form_id=360006493753).

