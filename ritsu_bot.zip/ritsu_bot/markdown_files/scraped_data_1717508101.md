Depending on the foundation or institution providing the scholarship, the
application period and results announcement period vary, so there is no pre-
set date on which results are announced.  
Every time the information on a scholarship is delivered to Ritsumeikan, the
International Center chooses students to be recommended for the scholarship,
and contacts the students directly.

To inquire about this matter, please contact the International Center Scholarship Desk at [rscholar@st.ritsumei.ac.jp](mailto:rscholar@st.ritsumei.ac.jp).

