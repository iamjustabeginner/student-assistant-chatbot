# Group English Tests (Institutional Program)

Ritsumeikan University conducts group English tests using external examination
such as TOEIC® L&R Test (IP) and TOEFL® ITP Test several times a year on
campus to measure the level of achievement in curricular classes, and for
self-assessment of proactive foreign language learning.  
Please utilize the group English test to check your level of English or to
prepare for the future, such as for studying abroad, advancement to a graduate
school, or job-seeking activities.

*For details on the type, schedule, application method, and guide of the test which is conducted as group English test, please check the Language Education Center website.
#### The website of Group English Test

<https://www.ritsumei.ac.jp/gengo/gaikokugo-gakusyu/dantai.html/>  
*Some faculties require their students to take these exams, and some also have a subsidy system for test fees. Please check the details prior to applying for the test. 
**For inquiries**  
Language Education Center  
<https://www.ritsumei.ac.jp/gengo/other/introduce.html/#tab-3>  
Kinugasa: Shogakukan 1F  
BKC: Central Arc 2F  
OIC: Building A 1F AN Office  

