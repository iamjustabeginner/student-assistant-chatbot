In order to participate in a study abroad program, you must have received the
annual health examination conducted by the Medical Service Center. If you did
not receive the health examination for whatever reason, you will have to have
a separate health checkup by a designated date.

*For inquiries, please contact the study abroad staff at the International Center [＜Here＞](https://global.support.ritsumei.ac.jp/hc/en/requests/new?ticket_form_id=360006493753).

