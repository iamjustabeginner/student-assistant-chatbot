In addition to the International Center, the Beyond Borders Plaza (BBP) on
each campus offers consultations with faculty members.*  
*Intercultural Advising Desk  
For information on how to use this resource, please refer to the following.

Beyond Borders Plaza (BBP): <http://www.ritsumei.ac.jp/bbp/>  
Contact the following email to make an appointment for the Intercultural
Advising Desk:  
KIC: kic-bbp@st.ritsumei.ac.jp  
OIC: oic-bbp@st.ritsumei.ac.jp  
BKC: bkc-bbp@st.ritsumei.ac.jp

*For inquiries, please contact the study abroad staff at the International Center [＜Here＞](https://global.support.ritsumei.ac.jp/hc/en/requests/new?ticket_form_id=360006493753).

