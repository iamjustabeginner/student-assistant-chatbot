We encourage you to make the most of the opportunities available on campus
such as CLA courses offered by the Language Education Center/ Center for
Language Acquisition and Foreign Language Communication Rooms. In addition,
the Beyond Borders Plaza (BBP) has a support desk where students can consult
with foreign language teachers regarding language learning generally. Please
feel free to make use of these resources.

For inquiries, please contact the study abroad staff at the International Center[＜Here＞](mailto:ru-sa@st.ritsumei.ac.jp).
Language Education Center (Japanese only): <http://www.ritsumei.ac.jp/gengo/>  
Center for Language Acquisition (Japanese only):
<http://www.ritsumei.ac.jp/gengo/cla/>  
Foreign Language Communication Rooms:
<http://www.ritsumei.ac.jp/bbp/reservation/>  
Beyond Borders Plaza (BBP): <http://www.ritsumei.ac.jp/bbp/>  
Support Desk: <http://www.ritsumei.ac.jp/bbp/reservation/>

*For inquiries, please contact the study abroad staff at the International Center [＜Here＞](https://global.support.ritsumei.ac.jp/hc/en/requests/new?ticket_form_id=360006493753).

