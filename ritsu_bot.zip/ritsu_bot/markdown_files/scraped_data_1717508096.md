Please submit a Notification for Temporarily Leaving Japan using the following
URL.  
Also, for those students living in one of the university's International
Dormitories (I-HOUSE/G-HOUSE), please do not forget to submit the necessary
Notification of Overnight Stay.

  
**< Notification for Temporarily Leaving Japan>**

[**Click here**](https://cw.ritsumei.ac.jp/campusweb/SVA20D0.html?key=SUR20200429161752422409989) or read QR code below  
****  

