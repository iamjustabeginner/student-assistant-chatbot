For the programs within the same category with the same application period and
program schedule, you can apply for multiple programs or courses at the same
time. In addition, there is no advantage or disadvantage to applying to one
program or several in terms of selection.  
  
If you strongly desire to study abroad, we recommend that you apply for more
than one program.

However, please note that students are not allowed to apply to a one semester
program and long-term program simultaneously.

*For inquiries, please contact the study abroad staff at the International Center [＜Here＞](https://global.support.ritsumei.ac.jp/hc/en/requests/new?ticket_form_id=360006493753).

