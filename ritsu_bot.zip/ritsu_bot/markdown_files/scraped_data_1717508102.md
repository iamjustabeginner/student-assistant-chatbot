You can look for housing on the internet. There is information on searching
for housing and about housing guarantors at the following URL:

<http://en.ritsumei.ac.jp/lifecareer/student-support/>

