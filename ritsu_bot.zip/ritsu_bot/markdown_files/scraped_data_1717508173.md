Information regarding program fee payment will be announced during the
guidance session for successful applicants.

In general, you will have to pay the program application fee within one week
after passing the screenings, and the remaining amount after subtracting the
program application fee from the total program cost will need to be paid one
month to two weeks before departure.  
It is necessary to pay tuition to the university regardless of the program fee
payment.  
Please make tuition payments following the procedure provided by RU’s Division
of Financial Affairs.

*For inquiries, please contact the study abroad staff at the International Center [＜Here＞](https://global.support.ritsumei.ac.jp/hc/en/requests/new?ticket_form_id=360006493753).

