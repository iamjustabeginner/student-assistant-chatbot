For the Fall semester of 2022, the results will be announced in mid-Nov.
Beginning with the 2022 academic year, we will be able to announce the results
of tuition fee reductions to students prior to the tuition payment deadline.

However, undergraduate students have their first year's tuition reduction
decided based on their performance on the entrance examination before entering
the university.

