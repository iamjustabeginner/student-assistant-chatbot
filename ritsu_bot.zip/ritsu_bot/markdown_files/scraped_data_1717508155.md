The following is a list of major public and private scholarships for study
abroad that are available to individuals and notified to the university from
organizations. Please check the application guidelines and apply directly on
your own. Please note that some scholarships cannot be combined with other
scholarships.

You can search for scholarships from external organizations. (Only in
Japanese)

  * [Search for Study Abroad Scholarships / Study Abroad Information Website (jasso.go.jp) ](https://ryugaku.jasso.go.jp/form/search.php?f=scholarship_abroad.html)
  * [Scholarship website "Gaxy"](https://gaxi.jp/)

