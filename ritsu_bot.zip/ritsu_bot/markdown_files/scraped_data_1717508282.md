# General Education Courses Conducted in a Foreign Language

  

International Liberal Arts Subjects (Group B Liberal Arts Courses) intend to
lay the foundations for cultivating mutual intercultural understanding, which
is vital in an increasingly globalized world.Courses use a foreign language,
and some classes are conducted in a lecture style while other classes are in
small groups with emphasis placed on active discussion.

Classes are made up of students from various colleges, grade years, countries
and global regions, and courses are divided into various stages so that
students can choose the appropriate ones based on their language abilities,
experience of international interaction, and study-abroad plans.

Thus, even students who doubt their abilities can easily join.

■The website of Liberal Arts Course  
<https://www.ritsumei.ac.jp/liberalarts/>

**For inquiries**  
Office of General Education  
Kinugasa: Yushinkan 1F  
BKC: Ad-Seminario 1F  
OIC: Building A 1F AN Administrative Office

