Information about study abroad programs offered by the International Center is
available through manaba+R notifications (category: “Study abroad”) and on the
Study Abroad Programs website.

For inquiries, please contact the study abroad staff at the International Center[＜Here＞](mailto:ru-sa@st.ritsumei.ac.jp).
Study Abroad Programs Website (Programs in Japanese) :
<http://www.ritsumei.ac.jp/studyabroad/>  
Study Abroad Programs Website (Programs in English) :
<http://www.ritsumei.ac.jp/studyabroad/eng/>

*For inquiries, please contact the study abroad staff at the International Center [＜Here＞](https://global.support.ritsumei.ac.jp/hc/en/requests/new?ticket_form_id=360006493753).

