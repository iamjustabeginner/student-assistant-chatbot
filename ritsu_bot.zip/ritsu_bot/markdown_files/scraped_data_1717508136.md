Part-time jobs are permitted as long as they do not impede study, for up to 28
hours per week.

Moreover, students are permitted to work up to 8 hours per day / 40 hours per
week during only long-term holidays designated in the school regulations
(summer, winter, and spring breaks).

