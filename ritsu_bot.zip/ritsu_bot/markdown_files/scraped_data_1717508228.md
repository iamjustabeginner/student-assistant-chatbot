### About The Career Center

The Ritsumeikan University Career Center offers a variety of career planning
events and placement support services for students. The Career Center aims to
help students achieve their individual career goals.  
  
International students are welcome to attend the events and utilize the
services provided by the Career Center. We strongly encourage you to take
advantage of the opportunities available to plan your future and find
employment.  

  * Kinugasa Career Center: 1st floor of Kenshinkan
  * BKC Career Center: 2nd floor of Prism House
  * OIC Career Center: 1st floor of Building A (AS office)

#### [Career Center Website (English)](https://www.ritsumei.ac.jp/career/en/)

