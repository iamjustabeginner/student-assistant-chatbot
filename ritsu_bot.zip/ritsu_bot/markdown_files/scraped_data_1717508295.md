# Tuition

For details on tuition, please refer to the “Academic Handbook For All
Undergraduate Students (II. Tuition)” and following page.

■URL：<https://www.ritsumei.ac.jp/tuitionfees/>

  

Your tuition bill include in the tuition payment guide is mailed to your
“Tuition Billing Address” registered at the University.

If Tuition Billing Address will change due to moving house or a change of
guarantor, etc., please promptly notify MANABI Station.

*The Tuition Payment Guide including tuition bill cannot be mailed overseas.If the tuition billing address is an overseas address, it must be changed. In that case, please notify Manabi Station.
  

#### ＜How to check your tuition billing address registered with the
University＞

Please visit [CAMPUS WEB](https://cw.ritsumei.ac.jp/campusweb/login.html) below and click “Confirm/Change Your Registered Information.”
**For inquiries**  
Finance & Accounting Office  
TEL:075-813-8164  

