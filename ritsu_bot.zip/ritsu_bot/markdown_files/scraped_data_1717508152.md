For study abroad programs offered by colleges or other RU academic
institutions,  
please check the details with each program’s administrative office (e.g.,
college administrative office, etc.).

