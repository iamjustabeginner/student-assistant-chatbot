In the event that your period of stay or your re-entry/special re-entry permit
expire, you must complete the following steps:

  1. Apply for and acquire a Certificate of Eligibility (COE) from the Japanese Immigration Bureau via university.
  2. Apply for and acquire a visa at the nearest Japanese Diplomatic Office.
  3. Enter Japan

If you need to apply for a COE, contact the International Center following the
steps below.

  1. Access **[t](https://global.support.ritsumei.ac.jp/hc/en-us/requests/new?ticket_form_id=360006867793)** _**[his web form](https://global.support.ritsumei.ac.jp/hc/en-us/requests/new?ticket_form_id=360006867793)**._
  2. Select “ 4. その他 (問合せ/連絡) Others (Inquiry/Contact)” from the list showed when you put your cursor on the first item “行いたい手続き Choose a procedure that you wish to proceed”.
  3. Enter each item and describe your situation.
  4. Attach your photo of both sides of your residence card.

  
  

