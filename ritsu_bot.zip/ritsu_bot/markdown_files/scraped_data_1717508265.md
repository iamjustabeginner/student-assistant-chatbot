# Extracurricular Activities

The website is about the University’s extracurricular activities.

<https://en.ritsumei.ac.jp/lifecareer/club-activities/>

Feature articles, the introduction of groups, and other related information
are posted.

<https://en.ritsumei.ac.jp/news/?tag=6>

  

The website describes matters concerning the borrowing of facilities or
equipment, the framework for financial support, and the rules when holding
events or delivering advertising within the University.

■Extracurricular Activities Handbook (Japanese text only)

<https://www.ritsumei.ac.jp/infostudents/handbook/>

■Support for extracurricular activities (Japanese text only)

<https://www.ritsumei.ac.jp/infostudents/activity/>

**For inquiries**  
Office of Student Affairs (Kinugasa)：Kenshinkan 2F  
Office of Student Affairs (BKC)：Central Arc 1F  
Office of Student Affairs (OIC)： Building A 1F AS Administrative Office

