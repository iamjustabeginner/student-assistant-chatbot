The English proficiency test required for application differs depending on the
program.  
If your score for one of the English exams listed in the application
guidelines meets the requirements, you can apply. For details, please check
the application guidelines for each program.

*For inquiries, please contact the study abroad staff at the International Center [＜Here＞](https://global.support.ritsumei.ac.jp/hc/en/requests/new?ticket_form_id=360006493753).

