Here is a representative list of discounted tickets for International Students
and the places where they can learn Japanese.

This is only a partial list. There will be other information available. We
encourage everyone to do your own research and exchange information with your
friends.

#

# Events

【kokoka】 Kyoto International Students Information Site (Lists of latest events)[Link](https://www.kcif.or.jp/web/en/members/)  
【Kyoto Prefecture】Job fairs and events for Int'l Students (Kyoto Job Park) (Japanese only)[Link](https://www.pref.kyoto.jp/jobpark/portal.html)  
# Discount Tickets/Passes, etc.

【Kyoto City Industrial Tourism Bureau】Lists of discount tickets convenient for
sightseeing in Kyoto (Japanese only)

[Link](https://ja.kyoto.travel/okoshiyasu/joushaken.html)  
【Hankyu Railway】2022 Kyoto Arashiyama 1day Pass, 2022 Ii Koto Ticket, etc. (Japanese only)[Link](https://www.hankyu.co.jp/ticket/otoku/)  
【Keihan Eizan Electric Railway】Hieizan Enryakuji Pilgrimage Eizan Train Ticket, Kyoto Ichijoji Ramen Ticket, etc. (Japanese only)[Link](https://eizandensha.co.jp/good-value/#eizan)  
【Kyoto Municipal Transportation Bureau】Subway, Bus 1day Pass[Link](https://oneday-pass.kyoto/?lang=en)  
【kokoka】Ryugakusei Okoshiyasu Pass（appeared in the middle of the page.）[Link](https://www.kcif.or.jp/web/en/members/)  
【Kyoto City】Kyoto Students App KYO-DENT (Link is Japanese) ([English flyer is here](https://www.city.kyoto.lg.jp/sogo/cmsfiles/contents/0000265/265798/A4_kyo-dent_e_20200318.pdf).)[Link](https://www.city.kyoto.lg.jp/bunshi/page/0000111091.html)  
【Osaka Convention & Tourism Bureau】Osaka e-Pass, etc.[Link](https://osaka-info.jp/en/information/ticket/travel-passes/index.html)  
【Japan】 Museum & Art Museum Campus Members  
By showing your student or faculty/staff ID, you can receive free admission or
discount on exhibitions.

[Link 1](https://www.ritsumei-fubo.com/activities/members/)  
[Link 2](https://www.ritsumei.ac.jp/file.jsp?id=244102&f=.pdf)  
# Places to learn Japanese

【kokoka】Where you can learn Japanese (Japanese lessons taught by volunteers, etc.）[Link](https://www.kcif.or.jp/web/en/livingguide/learnjapanese/)  
【Kyoto Prefectural International Center】Japanese classes for International Residents[Link](https://www.kpic.or.jp/english/learning_japanese/japanese_course/index.html)  
【Ibaraki City】Practical Japanese Class of IFAI[Link](http://www.ibaraki-nihongo.sakura.ne.jp/English.html)  
【Shiga Prefecture】Japanese classes in Shiga[Link](https://www.s-i-a.or.jp/en/useful-list/246)  
# Multi-cultural Understanding/Exchange

【kokoka】COSMOS[Link](https://www.kcif.or.jp/web/en/classes/cosmos/)  
【kokoka】Introducing culture to children in Japan[Link](https://www.kcif.or.jp/web/en/events/picnik/index.php)  
#

