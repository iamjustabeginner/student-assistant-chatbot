When you are able to apply for your visa at the nearest embassy (consulate),
please do so.

If three months pass AFTER the issuance date listed on the Certificate of Eligibility (whicn means expired), please refer to [this question](https://global-support2-ritsumei.zendesk.com/hc/en-us/articles/360059529393).

