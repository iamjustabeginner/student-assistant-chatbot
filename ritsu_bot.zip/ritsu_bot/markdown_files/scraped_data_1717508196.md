Liberal Arts Subjects Group B (International Liberal Arts Subjects) has a
study abroad course category. Courses are offered that allow students to
prepare for studying abroad and participate in intercultural exchange.  
For details, please check the Liberal Arts Education Center website.

For inquiries, please contact the study abroad staff at the International Center[＜Here＞](mailto:ru-sa@st.ritsumei.ac.jp).
Liberal Arts Education Center Website (Japanese only):
<http://www.ritsumei.ac.jp/liberalarts/course2019/detail/course08.html/>

*For inquiries, please contact the study abroad staff at the International Center [＜Here＞](https://global.support.ritsumei.ac.jp/hc/en/requests/new?ticket_form_id=360006493753).

