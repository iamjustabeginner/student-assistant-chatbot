  * This program provides partial financial support for those who are expected to have difficulty participating or continuing to participate in the program due to financial difficulties. 
  * The following criteria must be met

Total amount of annual income of living dependents such as your parents

Example: Annual income before tax: Below ¥6,000,000 or business income: below
¥1,970,000

  * Application procedures are required. Please check the Ritsumeikan University Study Abroad Program webpage and manaba frequently for application information.
  * [**2025 First Round Application Guidelines**](/hc/article_attachments/28355679519123)

