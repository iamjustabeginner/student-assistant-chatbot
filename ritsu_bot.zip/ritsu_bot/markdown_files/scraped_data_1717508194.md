Before applying for a study abroad program, please create a subject
registration plan that takes into account your period of study abroad and
consult with your college’s administrative office (or Manabi Station for the
OIC).  
Make sure that you plan thoroughly, including not only courses taken before
studying abroad but also those to be taken after returning to Japan.

*For inquiries, please contact the study abroad staff at the International Center [＜Here＞](https://global.support.ritsumei.ac.jp/hc/en/requests/new?ticket_form_id=360006493753).

