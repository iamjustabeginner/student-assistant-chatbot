Ritsumeikan University has study abroad programs offered by the International
Center for all undergraduate students as well as programs uniquely offered by
RU colleges and other RU academic institutions.  
Please check the links below for the various study abroad programs available
at Ritsumeikan University.  
You can check the details on study abroad programs offered by the
International Center for all undergraduate students on the Study Abroad
Program website.

Please note that some programs are only available in Japanese.

For inquiries, please contact the study abroad staff at the International Center[＜Here＞](mailto:ru-sa@st.ritsumei.ac.jp).
Ritsumeikan University Study Abroad Programs (Programs available in English) :
<http://www.ritsumei.ac.jp/studyabroad/eng/>  
Study Abroad Programs Website (Japanese) :
<http://www.ritsumei.ac.jp/studyabroad/>  

