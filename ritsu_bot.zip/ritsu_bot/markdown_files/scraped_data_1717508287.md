# Study at APU (Domestic Study-Exchange)

  

Ritsumeikan Asia Pacific University (APU) Student Exchange Program is a
program where students learn at APU located in Oita Prefecture under the
domestic exchange program and can earn credits.  
The periods of the outbound program are the following four: one year, spring
semester, fall semester, summer session (one week in the summer period).  
For application guidelines or guidance information, please visit and check the
following website.

■The website for domestic exchange programs at Ritsumeikan Asia Pacific
University  
<https://www.ritsumei.ac.jp/life/apu/>

**For inquiries**  
Kinugasa Manabi Station：[apu-tank@st.ritsumei.ac.jp](mailto:apu-tank@st.ritsumei.ac.jp)

