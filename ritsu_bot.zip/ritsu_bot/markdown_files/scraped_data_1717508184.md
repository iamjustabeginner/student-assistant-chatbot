The time that application guidelines are made available differs for short-term
study abroad, one semester study abroad, and long-term study abroad.  
Please inquire at the International Center, or check manaba+R or the Study
Abroad Programs website.

You may refer to the following as a guide.  
・Summer short-term/ one semester study abroad programs (available in April)
*All programs are only available in Japanese  
・Spring short-term/ one semester study abroad programs (available in July and
September) *All programs are only available in Japanese.  
・Fall departure long-term study abroad programs (available in October) * 3
programs are available in English.  
・Spring departure exchange programs (available in May and July) - *1 program
is available in English

For inquiries, please contact the study abroad staff at the International Center[＜Here＞](mailto:ru-sa@st.ritsumei.ac.jp).
Study Abroad Programs Website (for programs available in Japanese):
<http://www.ritsumei.ac.jp/studyabroad/>[  
  
](http://www.ritsumei.ac.jp/studyabroad/)Application Requirements (for
programs available in English):
<https://secure.ritsumei.ac.jp/studyabroad/eng/>

*For inquiries, please contact the study abroad staff at the International Center [＜Here＞](https://global.support.ritsumei.ac.jp/hc/en/requests/new?ticket_form_id=360006493753).

