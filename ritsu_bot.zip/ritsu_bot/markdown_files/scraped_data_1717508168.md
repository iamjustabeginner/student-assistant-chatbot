Even if you have a chronic illness (or an injury or illness currently being
treated), you can still apply to study abroad programs.  
However, after you decide to participate in a study abroad program, you must
report your health condition. Based on your declared information, the school
doctor at the Medical Service Center will check whether your health condition
allows you to study abroad.  
If necessary, the school doctor may communicate with participants or their
doctors.

*For inquiries, please contact the study abroad staff at the International Center [＜Here＞](https://global.support.ritsumei.ac.jp/hc/en/requests/new?ticket_form_id=360006493753).

