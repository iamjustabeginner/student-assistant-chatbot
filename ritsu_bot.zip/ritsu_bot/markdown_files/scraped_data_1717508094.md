This is because the university is required by the Ministry of Education,
Culture, Sports, Science and Technology to report any international students
who have been absent for a long period of time.  
During these monthly checks, we confirm whether students are conducting
study/research that corresponds to their "Student (留学)" status of residence.

Currently, we are setting monthly questionnaire for attendance confirmation on
manaba+R. Please scan QR code below and answer.

  
<https://ct.ritsumei.ac.jp/ct/course_2784415_survey>

