Information for international students enrolling into Ritsumeikan University's
colleges and graduate schools from April 2024 will be uploaded on this page
beginning from March 1st.

* * *
## Contents

#### 1\. Orientation session for new international students, hosted by the
International Center

#### 2．From pre-arrival to post-entry into Japan

2-1 Newly entering Japan (Steps from visa acquisition to entry)

2-2 Complete these procedures at your city hall/ward office

2-3 Submit a copy of your residence card to the University

#### 3．Important information for life as an international student at
Ritsumeikan University

3-1 Materials covered during orientation

3-2 Things every international student must remember to do while enrolled

3-3 Useful information for student life

* * *
  
(Last Updated 2024/4/1 14:40)

# 1\. Orientation session for new international students, hosted by the
International Center

Orientation for new international students will be held on the dates below in
a hybrid style, with participants allowed to choose to attend either in-person
or via Zoom. Orientation will cover important information for international
students, such as status of residence, application procedures for scholarships
and tuition reduction, and what to do when facing problems in your student
life, so make sure to attend.

### Date & Time, Format, and Pre-registration

  * **Date and Time:  
** Monday, March 25th, 13:00 - 14:30 (Japan Standard Time)  
*Students enrolling into a degree program conducted in Japanese should see the [Japanese language orientation page](https://global.support.ritsumei.ac.jp/hc/ja/articles/26345554523027).

  * **Format:  
** In-person and live-streamed over Zoom  
*You may come to campus and attend in-person or participate over Zoom.  

    * To attend in-person, please visit:  

      * Kinugasa: Meigakukan Hall(明学館), 1st Floor, MG101
      * BKC: Integration Core/Rarcadia, 1st Floor, R101
      * OIC: A-Building, 1st Floor, AC130

  * **Pre-Registration: All students must pre-register!**  
All students must pre-register for either in-person or online attendance from
the link below. Request of pre-registration will also be announced by e-mail.  
<https://ritsumei-ac-
jp.zoom.us/meeting/register/tJwpce6hrzosE9DVbwG-9u3Gtu2CNK1UBGPs>

  
#

# 2\. From pre-arrival to post-entry into Japan

### 2-1 Newly entering Japan (Steps from visa acquisition to entry)

Please check [this page](https://global.support.ritsumei.ac.jp/hc/en-us/sections/360010905954--Procedure-before-coming-to-Japan) for necessary procedures if you are going to enter Japan on a new "STUDENT" visa.
###

### 2-2 Complete these procedures at your city hall/ward office

  * All three procedures below can be done at your city hall/ward office
  * For (3), you'll first need your student ID card. If you won't be able to obtain your student ID card from within 14 days of moving-in, or if you want to open a bank account as soon as you receive your student ID card, complete (1) and (2) first.
  * After completion of these procedures you will receive a variety of important notices in the mail. Make sure to read them!

**(1)Register your address**

  * Multiple public services will become available to you after registration.
  * Students with a status of residence in Japan **are obliged** to report their address to the city hall/ward office upon arrival in Japan and any time there is a change of address thereafter.
  * Please register your address **within 14 days** of moving in.
  * After registration you will be able to order a Residence Certificate. Students who couldn't submit a Residence Certificate when completing their admission procedures should apply for one at this time.
  * Procedures are described in detail on [the Website of Ministry of International Affairs and Communications](https://www.soumu.go.jp/main_sosiki/jichi_gyousei/c-gyousei/zairyu/english/move-in_move-out.html).

  
**(2)Enroll in National Health Insurance**

  * National Health Insurance is the public health insurance system in Japan. All international students who will stay in Japan for 3 months or more **must** enroll.
  * After joining the National Health Insurance you will have to pay the premium, but on the up-side you will only be responsible to cover **30% of the cost** incurred for treatment at the doctor's office. (**Without this insurance you are responsible for 100%)**
  * Premiums are based on your taxable income in Japan the previous year, **so as a student you must report your income each year**. Be careful, **your premium may increase dramatically if you fail to report your income**. (You will receive relevant paperwork in the mail annually beginning from the next fiscal year.)
  * For more details and to learn about subsidies from the university, [see here.](https://en.ritsumei.ac.jp/current-students/dailylife/health/)

  
**(3)Enroll in the National Pension System**

  * The National Pension System allows for income security for the elderly and disabled. Those between the ages of 20 to 60 who live in Japan, including foreigner nationals, must enroll.
  * After joining the National Pension you will be responsible to pay the premium, however, **students can be exempted or defer payment with the[Special Payment System for Students](https://www.nenkin.go.jp/faq/kokunen/nonjapanesepeople/student.html)**. (A student ID card is required to apply for payment exemption/deferment.)

Read more about National Pension [here](https://www.nenkin.go.jp/faq/kokunen/nonjapanesepeople/student.html).  
✅Reference

For more on what to bring in order to complete procedures and things to keep
in mind afterwards, also refer to the homepage of your local city hall/ward
office, international exchange center, etc.

Kyoto

  * [Kyoto City International Foundation HP-Procedures at a Ward Office ](https://www.kcif.or.jp/web/en/livingguide/wardoffice/)
  * [City of Kyoto Procedures at the Ward Office (PDF)](/hc/article_attachments/27352624882963)
  * [The explanation about letters (documents) sent from the ward offices.](/hc/article_attachments/26918574743571)

  
Kusatsu and Otsu

  * [Shiga Intercultural Association for Globalization HP - Living Guide Q&A](https://www.s-i-a.or.jp/en/qa/immigration_residency_procedures)
  * [Administrative Procedures at City Hall (PDF)](/hc/article_attachments/27003109399059)
  * [Otsu City Form Samples](/hc/article_attachments/26918562324883)

  
Ibaraki

  * [Ibaraki City HP- About resident registration to the foreign membership](https://www15.j-server.com/LUCIBARAKI/ns/tl.cgi/https://www.city.ibaraki.osaka.jp/kurashi_tetsuzuki/koseki_touroku/juminhyo/53662.html?SLANG=ja&TLANG=en&XMODE=0&XCHARSET=utf-8&XJSID=0)

  
###

### 2-3 Submit photos of your residence card to the University

  * All international students **must submit photos of their residence card, which includes their up-to-date address on the back-side, to the university**. Submit photos of your residence card (front and back) via [**this form📄**](https://global.support.ritsumei.ac.jp/hc/en-us/articles/1500000457041)
  * To access the form you must log in using your RAINBOW ID, **which will be distributed to all regular students via[Ritsu-Mate](http://www.ritsumei.ac.jp/applicants/) on March 31st at 10:00**.*RAINBOW IDs for SKP and other non-regular students will be distributed separately by the responsible offices in charge.

About [RAINBOW user ID and password](https://it.support.ritsumei.ac.jp/hc/ja/articles/900006767503-RAINBOW%E3%83%A6%E3%83%BC%E3%82%B6%E3%83%BCID-%E5%AD%A6%E7%94%9F-%E3%81%AE%E5%88%A9%E7%94%A8%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6#).
  * Submit your residence card photos by **Wednesday, April 10th.**

#

# 3\. Important information for life as an international student at
Ritsumeikan University

### 3-1 Materials covered during orientation

  * Materials covered during orientation on Monday, March 25th will be released [here](/hc/article_attachments/27974209558803) **afterwards**.
  * If you were unable to attend orientation or would like to review the information afterwards, please review them as needed.

### 3-2 Things every international student must remember to do while enrolled

  * The Immigration Bureau has granted you the residence status "Student"(留学) specifically for conducting study and research at Ritsumeikan University.
  * If you are not studying or conducting research at the university or if we are unable to get in contact you, you will be considered as residing in Japan illegally or as a missing person, and will be liable to lose your "Student" residence status.
  * Even if you are studying or conducting research, if you forget to apply for an extension of your period of stay you may be deemed as residing in Japan illegally.
  * To avoid this situation, please remember to do the following.

**No.****What needs to be done****When to do it****How to do it**  
**1**

Submit residence card photos

  * At the time of enrollment
  * When any info on your residence card changes (extension of period of stay, change in resident status or address, etc.)
  * Whenever requested to do so by the university (Each year in April, etc.)

[Web Form](https://global.support.ritsumei.ac.jp/hc/en-us/articles/1500000457041)  
**2**

Extend your Period of Stay

  * Before the period of stay expires  
*The procedure can be started 3 months prior to the expiration date

[See this page](https://global.support.ritsumei.ac.jp/hc/en-us/articles/360057679614)  
**3** Confirm attendance

  * Every month*Students who have not yet entered Japan must also confirm attendance

[See this page](https://global.support.ritsumei.ac.jp/hc/en-us/articles/360057680094)  
**4** Register/update your personal information

  * When you change your phone number, etc.

[See this page](http://www.ritsumei.ac.jp/pathways-future/eng/student_life/personal_info.html/)  
**5** Submit Notification for Temporarily Leaving Japan

  * When leaving Japan temporarily  
（e.g. When you return to your home country for summer vacation）

[See this page](https://global.support.ritsumei.ac.jp/hc/en-us/articles/360059530033)  
### 3-3 Useful information for student life

The following section contains information you should know as a student of
Ritsumeikan University. Particularly important points will be covered during
orientation.

**No.****Topic****Materials**  
**1** International Center  
Online Support Desk

The Online Support Desk is where you can go any time you have questions, wish
to seek consultation, need to apply for or submit something to the
International Center.

[What you can do at, and how to use, the Online Support Desk](http://www.ritsumei.ac.jp/file.jsp?id=509189)  
**2** International Student Quick Guide *scheduled for release in March[The Quick Guide](https://global.support.ritsumei.ac.jp/hc/en-us/sections/24493772417939--Quick-Guides) provides important life and study info for international students at Ritsumeikan University.  
**3** Tuition reduction and scholarships

Read [this](/hc/article_attachments/26918562308883) to learn how to apply for tuition reduction and/or scholarship after enrollment  
**4**

Opening a bank account

Document to learn how to open a Japan Post (Yucho) Bank account will be posted [here](/hc/article_attachments/27007109804435).  
**5** Study Support Site  

The [Study Support Site](http://www.ritsumei.ac.jp/pathways-future/eng/) provides info on course registration, classes, grades, enrollment status and the like.  
**6** Commuting to campus by bicycle

To **must** take "Commuting Guidance" (video on demand) and register before
you can commute to campus by bicycle.

1) "Commuting Guidance" and Information on Commuting on a motorbike or bicycle is [here.](https://www.ritsumei.ac.jp/pathways-future/eng/student_life/private_transportation.html/)  
*Bicycle Registrations at **Kinugasa Campus** must be applied at designated date and place. For further details, please click [here](/hc/article_attachments/26918562328467)
*Bicycle Registrations at **Osaka Ibaraki Campus** must be applied at designated date and place. Further details are TBA.
2) Please read about the bicycle rules in your area below.  
KIC: [Bicycle rules and etiquette in Kyoto](https://kyoto-bicycle.com/en/rental_search#rules)  
BKC: [Commuting to School by Bicycle, Motorbike, or Car](https://en.ritsumei.ac.jp/lifecareer/commuting-to-school/)  
OIC: [Bicycle Traffic Safety Rulebook in Osaka](https://www.police.pref.osaka.lg.jp/kotsu/taisakushitsu/1_1/5863.html#)  
**7** IT support: Wi-Fi, uni email, media labs, etc.

1) [BEGINNER'S GUIDE for students](https://it.support.ritsumei.ac.jp/hc/ja/articles/900006720603)  
2) [Set-up of multi-factor authentication**(Mandatory)**](https://it.support.ritsumei.ac.jp/hc/ja/articles/20526609153177-%E6%96%B0%E5%85%A5%E7%94%9F%E5%BF%85%E8%A6%8B-%E5%A4%9A%E8%A6%81%E7%B4%A0%E8%AA%8D%E8%A8%BC%E3%82%92%E8%A8%AD%E5%AE%9A%E3%81%97%E3%82%88%E3%81%86#)
*Language setting required at the top right ▼英語＝English  
**8** Using the library and database

1) [LIBRARY GUIDE](http://www.ritsumei.ac.jp/lib/f04/010/)  
2) [Library Guidance for New Students (Video On Demand)](https://www.ritsumei.ac.jp/lib/d01/010/032/)  
3) [Library Homepage](https://www.ritsumei.ac.jp/lib/)  
**9** Office of Student Affairs

[Orientation Information Sheet (PDF)](/hc/article_attachments/27974473994771)  
**10** Medical Service Center

1) [Visiting a clinic in town or on campus, and how to prevent transmittable disease](https://www.pip-maker.com/?view=0pkd)(Video)
* **Must** watch this video before starting course.  
2) [Medical Service Center Homepage](http://en.ritsumei.ac.jp/health/) (yearly health exams, etc.)
* **Must** visit Medical Service Center's website during the first week of April and make a reservation for on-campus medical examination.   
**11** Invitation for Ritsumeikan CO-OP and their Campus Tours

1)[Orientation Information Sheet (PDF)](/hc/article_attachments/27974323875347)
2)[Membership Application Information(PDF)](/hc/article_attachments/27974323875347)
3) [CO-OP Student Comprehensive Mutual Insurance(PDF)](/hc/article_attachments/27974323878035)
4)<Kinugasa Campus> [Campus Tour for Int'l Students (PDF)](/hc/article_attachments/27561338573331)  
**12** Job hunting in Japan and University support  
(Career Center)[Orientation Information Sheet (PDF)](/hc/article_attachments/27974306154643)  
【Following files are some of the materials listed above】

