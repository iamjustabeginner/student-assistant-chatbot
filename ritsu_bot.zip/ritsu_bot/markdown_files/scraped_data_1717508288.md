# Support for Japanese skills of International Students

#### Interactions between international students and Japanese students and
support for international students

The following website lists various student groups within the University which
support international students.

■Interactions between international students and Japanese students

<https://www.ritsumei.ac.jp/international/intl_exchanges/>

**For inquiries**  
International Center  
Kinugasa: Meigakukan 1F  
BKC: Central Arc 2F  
OIC: Building A 1F AN Administrative Office  

#### Consultation on Japanese Learning

Learning consultation services with the purpose of supporting Japanese
learning are provided at each campus.  
Japanese instructors are available for consultation on Japanese learning
during a given period of time.  
Please feel free to visit there.  
The time schedule and implementation site will be announced on the
University’s website and manaba+R before the start of each semester.

■Center for Japanese Language Education HP

<https://www.ritsumei.ac.jp/nihongo/current_stude/ >

■Beyond Borders Plaza HP

<https://www.ritsumei.ac.jp/bbp/>

**For inquiries**  
Language Education Center  
<https://www.ritsumei.ac.jp/gengo/other/introduce.html/#tab-3>  
Kinugasa: Shogakukan 1F  
BKC: Central Arc 2F  
OIC: Building A 1F AN Office  

