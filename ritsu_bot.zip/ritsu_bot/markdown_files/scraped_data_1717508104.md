There are dormitories for international students. Exchange students living in
Japan for 6 months to 1 year, and newly admitted regular students can live
there. Depending on the campus, conditions to live in the dormitory change, so
please refer to the following website for more details:

・International Center Home Page <http://en.ritsumei.ac.jp/lifecareer/student-
support/>

