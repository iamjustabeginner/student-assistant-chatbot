## RU Educational System

[RU Educational System](/academics-e/system)
## Undergraduate School

[E]: Includes English-based Degree Programs
### Colleges at Kinugasa Campus

[College of Law](/academics-e/college-of-law)
[College of Social Sciences](/academics-e/college-of-social-sciences)
[College of International Relations [E]](https://www.ritsumei.ac.jp/ir/eng/)
[College of Letters](/academics-e/college-of-letters)
### Colleges at Biwako-Kusatsu Campus

[College of Economics](/academics-e/college-of-economics)
[College of Sport and Health Science](/academics-e/college-of-sports-health-science)
[College of Science and Engineering](/academics-e/college-of-science-and-engineering)
[College of Life Sciences](/academics-e/college-of-life-sciences)
[College of Pharmaceutical Sciences](/academics-e/college-of-pharmaceutical-sciences)
[College of Gastronomy Management](/academics-e/college-of-gastronomy-management)
### Colleges at Osaka Ibaraki Campus

[College of Business Administration](/academics-e/college-of-business-administration)
[College of Policy Science [E]](https://en.ritsumei.ac.jp/ps/)
[College of Comprehensive Psychology](/academics/college-of-comprehensive-psychology/)
[College of Global Liberal Arts [E]](https://en.ritsumei.ac.jp/gla/)
[College of Image Arts and Sciences](/academics-e/college-of-image-arts-and-sciences)
[College of Information Science and Engineering [E]](https://en.ritsumei.ac.jp/ise/)
## Graduate School

[E]: Includes English-based Degree Programs
### Graduate Schools at Kinugasa Campus

[Graduate School of Law](/academics-e/graduate-school-of-law)
[Graduate School of Sociology](/academics-e/graduate-school-of-sociology)
[Graduate School of International Relations [E]](https://www.ritsumei.ac.jp/gsir/eng/)
[Graduate School of Letters](/academics-e/graduate-school-of-letters)
[Graduate School of Language Education and Information Science](https://www.ritsumei.ac.jp/acd/gr/gsli/e/index.html)
[Graduate School of Core Ethics and Frontier Sciences](https://www.r-gscefs.jp/en/)
### Graduate Schools at Biwako-Kusatsu Campus

[Graduate School of Economics [E]](https://www.ritsumei.ac.jp/gsec/mped/)
[Graduate School of Sport and Health Science](/academics-e/graduate-school-of-sports-health-science)
[Graduate School of Gastronomy Management](/academics-e/graduate-school-of-gastronomy-management)
[Graduate School of Science and Engineering [E]](https://www.ritsumei.ac.jp/gsse/eng/)
[Graduate School of Life Sciences [E]](https://en.ritsumei.ac.jp/gsls/)
[Graduate School of Pharmacy](https://en.ritsumei.ac.jp/gsph/)
### Graduate Schools at Osaka Ibaraki Campus

[Graduate School of Business Administration](/academics-e/graduate-school-of-business-administration)
[Graduate School of Policy Science [E]](https://www.ritsumei.ac.jp/gsps/eng/)
[Graduate School of Human Science](/academics-e/graduate-school-of-human-science)
[Graduate School of Technology Management [E]](https://www.ritsumei.ac.jp/mot/english/)
[Graduate School of Management](/academics-e/graduate-school-of-management)
[Graduate School of Image Arts](/academics-e/graduate-school-of-image-arts)
[Graduate School of Information Science and Engineering [E]](https://www.ritsumei.ac.jp/gsise/eng/)
### Graduate Schools at Suzaku Campus

[School of Law](/academics-e/school-of-law)
[Graduate School of Professional Teacher Education](/academics-e/graduate-school-of-education)

