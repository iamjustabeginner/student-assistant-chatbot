The Ritsumeikan University International Center has put together the
"International Student Handbook" for all international students. If you have
any questions, please refer to this handbook below as your first resource. It
can be downloaded on the International Center's homepage.

