Everyone under the "Student (留学)" status of residence has been permitted to
stay in Japan under the premise that they will get an education at a
university. For that reason, to engage in a part-time job, an activity not
permitted under the "Student (留学)" status of residence, you are required to
obtain "Permission to Engage in an Activity Other Than That Permitted under
the Status of Residence Previously Granted" at the immigration bureau before
engaging in said activity.

