If you would like to talk to the International Student Support Coordinator
individually, please make a reservation using the booking form below.

Within 3 days (excluding Sat, Sun, and national holidays, summer/winter/spring
vacation), we will send an email to your Ritsumeikan email address or the
address submitted on this form. If you do not receive an email from us within
3 days, please contact "ru-issc@st.ritsumei.ac.jp".  
  

Please feel free to talk to her if you find it hard to adapt to a new
environment, don’t know where to turn and who to talk to, etc. Do not hesitate
to make a reservation even if your worry is a small issue.

**Booking Form****  
（[Click here](https://forms.office.com/Pages/ResponsePage.aspx?id=jUNJpAY2C0mET8ThXlNfyjAJxxYEO0hJvJKlb5fDE3ZURTFRVTE0U1U5WlUxN0MxNklFWllUQkRaQy4u) or scan QR code below）**
****

