You can apply even if you do not have a passport at the time of application to
a study abroad program.  
However, you may need a passport as soon as your participation in the program
is decided for visa acquisition purposes, etc.  
  
Therefore, please apply for a passport while preparing your study abroad
program application without waiting for program application results.

*For inquiries, please contact the study abroad staff at the International Center [＜Here＞](https://global.support.ritsumei.ac.jp/hc/en/requests/new?ticket_form_id=360006493753).

