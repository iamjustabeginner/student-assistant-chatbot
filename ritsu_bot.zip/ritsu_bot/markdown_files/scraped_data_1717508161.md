For programs offered by the International Center, generally accommodation
arrangements will be made directly or intermediated by the International
Center (except for exchange programs, Global PBL and DUDP).  
Details will be provided in the application guidelines and during program
guidance sessions.

*For inquiries, please contact the study abroad staff at the International Center [＜Here＞](https://global.support.ritsumei.ac.jp/hc/en/requests/new?ticket_form_id=360006493753).

