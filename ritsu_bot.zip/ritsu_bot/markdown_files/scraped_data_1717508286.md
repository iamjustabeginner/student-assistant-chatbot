# Study Abroad Program [Programs Available to All the Undergraduate Students]

  

For study abroad programs offered to students of all colleges, please refer to
the Study Abroad Program website.

The Study Abroad Program website provides a variety of information on study
abroad, such as details of each program,application guidelines, scholarship
information, study abroad stories, and the latest information related to study
abroad,etc. Please make use of it.

■Study Abroad Program website  
<https://www.ritsumei.ac.jp/studyabroad/eng/>

  

International Center offers online counseling (request form or Zoom) for study
abroad.Please see below for details.

■Study Abroad Program website, page of 海外留学相談 (Counseling for Study
Abroad)Home > 情報収集 (Collecting Information）> 海外留学相談 (Counseling for Study
Abroad)  
<https://www.ritsumei.ac.jp/studyabroad/info/soudan.html/>(only available in
Japanese)

**For inquiries**  
International Center  
Kinugasa: Meigakukan 1F  
BKC: Central Arc 2F  
OIC: Building A 1F AN Administrative Office

