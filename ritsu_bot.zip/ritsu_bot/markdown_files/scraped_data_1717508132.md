There are many help desks, not only at Ritsumeikan, but in the towns that you
live in as well. We have listed some of the main ones for you:

  
**＜Ritsumeikan University＞**  
**・Student Support General Guide：**
<http://www.ritsumei.ac.jp/drc/sougou/en/detail/>  
**・International Center：** [Form for Inquiry/Submit](/hc/en-us/articles/1500000457041)
**＜Municipal Help Desks＞**  
**・Kyoto City International Foundation：**
<https://www.kcif.or.jp/web/en/livingguide/>  
**・Shiga Intercultural Association for Globalization：**
<http://www.s-i-a.or.jp/en/qa>  
**・Ibaraki City：**
<https://www.city.ibaraki.osaka.jp/kikou/shimin/bunka/menu/Foreigners/>

