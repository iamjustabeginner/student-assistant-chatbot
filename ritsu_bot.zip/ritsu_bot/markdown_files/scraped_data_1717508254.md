# Restriction on Double Registration

Students are not allowed to register with another university while being
registered at RU. However, double registration may be permitted if it is
considered necessary for the purposes of education and it does not interfere
with course requirements at both universities. Contact the administrative
office of your college (or the Osaka Ibaraki Campus (hereinafter referred to
as “OIC”) Manabi Station) for details.

Students who have received permission to take courses at other universities
within the Kyoto Consortium Credit Exchange System or via a program with
Ritsumeikan Asia Pacific University (hereinafter referred to as “APU”) do not
need to seek further permission from the University.

**For inquiries**  
Kinugasa: Administrative office of your college or Graduate School  
BKC: Administrative office of your college or Graduate School  
OIC: Manabi Station (Building A 1F AC Administrative Office)  
Suzaku: Administrative Office, Inter-Faculty Graduate Schools

