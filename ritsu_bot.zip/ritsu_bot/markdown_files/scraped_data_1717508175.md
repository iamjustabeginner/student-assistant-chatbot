There are no particular limitations to job hunting as long as it does not
interfere with studies and life while in a program.  
For example, some students have participated in career forums held at study
abroad destinations in the past.  
Please refer to the following information from RU’s Career Center and Global
Career information.

For inquiries, please contact the study abroad staff at the International
Center.

