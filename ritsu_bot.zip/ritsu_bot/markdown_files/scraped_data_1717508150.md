Please refer to the "Study Abroad Guide" posted on the Study Abroad Programs
website.  
  
Study Abroad Guide :
<http://www.ritsumei.ac.jp/studyabroad/common/file/tebiki_english_2020.pdf>  
Please refer to "Information Distribution Period" and "Application Period" of
each program.

*For inquiries, please contact the study abroad staff at the International Center [＜Here＞](https://global.support.ritsumei.ac.jp/hc/en/requests/new?ticket_form_id=360006493753).

