The tuition reduction will be applied only for the semester in which the
application is submitted and/or the following semester. In order to be
eligible for the tuition reduction, your enrollment status must be registered
as "current student (zaigaku)" or "study abroad (ryuugaku)".

If you take a leave of absence, the tuition reduction will not be applied to
that semester, nor will it be deferred.

