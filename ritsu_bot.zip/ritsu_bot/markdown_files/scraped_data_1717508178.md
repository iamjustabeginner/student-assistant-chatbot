The International Center does not handle privately-funded study abroad using
the “Leave of Absence” system.

Information about privately-funded study abroad may be provided by the Co-op
Travel Center and the study abroad agencies of private companies, so please
contact those groups if necessary.

