Because “Student” statuses of residence lose their validity upon graduation or
completion of studies, in order for international students who were studying
at Ritsumeikan University to continue to stay in Japan, it is necessary to
change their status of residence.

As indicated on the Immigration Services Agency’s website below, for those
students who have been searching for a job but their employer is not decided
by graduation, and wish to continue job hunting after graduation, it is
possible to change to a “Designated Activities” status of residence (valid for
6 months) as long as certain requirements are met. In order to apply to change
to a “Designated Activities” status of residence at the Immigration Bureau, a
letter of recommendation from Ritsumeikan University is required.  
＜Immigration Services Agency Website＞

<https://www.moj.go.jp/isa/applications/status/designatedactivities14.html?hl=en>

This status is only for **degree-seeking students** who will graduate from
Ritsumeikan University. Non-Degree students, auditing students, exchange
students, and research students cannot apply for this status.

Ritsumeikan University holds application periods twice per year for the
issuance of these letters of recommendation. International students from whom
the International Center receives an application will undergo a evaluation of
their studies, lifestyle condition, job hunting activities up to the time of
application, motivation for the field/industry of interest, and ability to pay
expenses, etc. A letter of recommendation will be issued to those students for
whom it is deemed appropriate. For the screening, applicants will complete an
online form, after which the International Center will conduct a document
review.

An information session on the issuance of these letters of recommendation will
be held on the following date. The information session will be held only once
and will be conducted online in both English and Japanese. Please be sure to
pre-register at the ZOOM link below.

**＜Information Session on the Issuance of “Designated Activities” Letters of
Recommendation (to be issued in March 2024)＞**

**Wednesday, January 31, 2024, 1:00 pm (about 90 minutes)** It has ended

*If for circumstances beyond your control, you are unable to attend the information session, the information session materials will be uploaded on this page, so please be sure to read them thoroughly.
*Those students who have decided on a career path must report their decision to the Career Center.
*Students who are graduating in September 2024 are welcome to participate in this information session, but are not allowed to apply during this application period. Students graduating in September 2024 who would like to request the issuance of a letter of recommendation should apply during the next application period (to be announced at a later time on the portal site)
＜Information Session Documents＞★2/2 Up

Department in chargeDocuments  
①【International Center】Application Guideline for Designated Activity[Document①](/hc/article_attachments/25852849800211)  
②【Career Center 】Support for Job Hunting[Document](/hc/article_attachments/25852849800211)[②](/hc/article_attachments/25852836224659)  
③【Osaka Employment Service Center for Foreigner】Support for Job Hunting[Document](/hc/article_attachments/25852849800211)[③](/hc/article_attachments/25853473758995)  
④【Osaka Immigration Bureau】Status of residence to work in Japan[Document](/hc/article_attachments/25852849800211)[④](/hc/article_attachments/25853504189331)  
＜ＵＲＬ for application＞★Will be released starting March 1

For application details, please check document ① in the table.

No.Required DocumentsWhere to Submit  
１

Application Form (3/1 (Fri.) - 4/30 (Tues.))

★You must register as a user to be able to apply. Register [HERE](/hc/article_attachments/26875238514195).
★Applicants should use the same form regardless of whether they are applying
to change from "Student" to "Designated Activities" status or renew their
"Designated Activities" status.

[**https://rw.ritsumei.ac.jp/survey/guest/SVA4FD0.html?key=LNG20240131111841404163265**](https://rw.ritsumei.ac.jp/survey/guest/SVA4FD0.html?key=LNG20240131111841404163265)  
２

A document proving your ability to support yourself financially

*Please submit one of the following: 1, 2, OR 3. (To prove your ability to support yourself for half a year, you must submit minimum, 600,000 JPY worth of proof)
  1. Copy of your personal Certificate of Bank Balance  

     * Must have been issued within one week of submitting your application.
     * In the case of a bankbook, submit the page with your name and the page with the latest balance.
     * Screenshots of online pages are also acceptable.
  2. Certificate of Remittance
  3. Certificate of Bank Balance of a financial supporter other than yourself  

     * In Japanese or English ONLY
     * Any currency is acceptable
     * Must have been issued within one month of submitting your application.

If submitting 3, you must also submit a [Statement of Financial Support](/hc/article_attachments/26875216033427).
Attach the file to the form above (pdf/jpg/png)  
【Inquiries】

International Center

[ru-coe@st.ritsumei.ac.jp](mailto:ru-inter@st.ritsumei.ac.jp)

