When studying abroad through a program offered by the International Center,
participants and their guarantors are asked to confirm and sign a consent
form. This is established as the minimum rule for you and other participants
to study abroad safely and securely.  
Violation of the form’s terms may result in being asked to return to Japan
before the end of your study abroad or return received scholarships.

*For inquiries, please contact the study abroad staff at the International Center [＜Here＞](https://global.support.ritsumei.ac.jp/hc/en/requests/new?ticket_form_id=360006493753).

