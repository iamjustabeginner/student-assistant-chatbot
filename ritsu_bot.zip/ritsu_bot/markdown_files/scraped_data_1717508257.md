# Reenrollment

**Procedures for Re-enrollment**  
  
Please check [here](/file.jsp?id=615586) for the procedure in case of reenrollment
*A student who took a leave of absence due to an illness must submit a physician’s note.
*A student who re-enrolls is required to pay the tuition for the academic year they are re-enrolling in.
**[Application period]**

**Semester of Re-enrollment**

**Application Period**  
Spring semester

Feb. 1 – end of Feb.  
Fall semester

Aug. 1 – end of Aug.  
**[Application period for international students who need to acquire a
residence status of “Student”]**

**Semester of Re-enrollment**

**Application Period**  
Spring semester

Dec. 1 – end of Dec.  
Fall semester

Jun. 1 – end of Jun.  
* If a student wishes to acquire a residence status of “Student,” the student needs to pay the tuition for the next semester within two weeks after the re-enrollment is approved. 
**Student Identification Numbers and Applicable Curriculum After Re-
enrollment**

After re-enrollment, student ID numbers and the curriculum of enrollment will
remain unchanged from prior to the leave of absence.

**< For inquiries>**

Kinugasa: Administrative office of your college or Graduate School

BKC: Administrative office of your college or Graduate School

OIC: Manabi Station (Building A 1F AC Administrative Office)

Suzaku: Administrative Office, Inter-Faculty Graduate Schools

