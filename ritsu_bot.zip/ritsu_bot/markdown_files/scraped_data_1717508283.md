# E-learning (Gyutto-e)

“Gyutto-e” is e-learning material for English learning.  
You can access it and study English anytime anywhere on your PC or smartphone.
You can also use it to prepare for the TOEIC® Test.  
Students of Ritsumeikan University can use it for free. (up to the first 2,000
students)  
Please make good use of it!

■The website of Language Education Center, E-Learning (Gyutto-e)  
<https://www.ritsumei.ac.jp/gengo/gaikokugo-gakusyu/e-learning.html/>

**For inquiries**  
Language Education Center  
<https://www.ritsumei.ac.jp/gengo/other/access.html/>

