## [💡Quick Guides](/hc/en-us/sections/24493772417939--Quick-Guides)
  * [Is there a page where I can find all the necessary information for international students?](/hc/en-us/articles/24493905237139-Is-there-a-page-where-I-can-find-all-the-necessary-information-for-international-students)

## [🎫Status of Residence](/hc/en-us/sections/360012032513--Status-of-Residence)
  * [After graduating, I plan to enter graduate school, but there will be a gap between graduation and entrance. Can I stay in Japan during this period?](/hc/en-us/articles/23699869172243-After-graduating-I-plan-to-enter-graduate-school-but-there-will-be-a-gap-between-graduation-and-entrance-Can-I-stay-in-Japan-during-this-period)
  * [How do I extend my status of residence?](/hc/en-us/articles/20674118615443-How-do-I-extend-my-status-of-residence)
  * [What should I do if my status of residence or re-entry permit expires while I am away from Japan?](/hc/en-us/articles/360057680114-What-should-I-do-if-my-status-of-residence-or-re-entry-permit-expires-while-I-am-away-from-Japan)
  * [How can I get the latest information on immigration procedures/policies/regulations?](/hc/en-us/articles/1500004874641-How-can-I-get-the-latest-information-on-immigration-procedures-policies-regulations)

## [📝Confirming Student Enrollment](/hc/en-us/sections/360012032533--Confirming-Student-Enrollment)
  * [At what times do I have to submit a copy of my Residence Card to the university?](/hc/en-us/articles/360059529353-At-what-times-do-I-have-to-submit-a-copy-of-my-Residence-Card-to-the-university)
  * [Why do International Students need to have their attendance confirmed every month?](/hc/en-us/articles/360057680094-Why-do-International-Students-need-to-have-their-attendance-confirmed-every-month)

## [🛬Procedure before coming to Japan](/hc/en-us/sections/360010905954--Procedure-before-coming-to-Japan)
  * [How can I apply for a Certificate of Eligibility (COE) to enter Japan? ](/hc/en-us/articles/23002398311699-How-can-I-apply-for-a-Certificate-of-Eligibility-COE-to-enter-Japan)
  * [【Spring Semester 2024】 International Students at Kinugasa Campus](/hc/en-us/articles/17954181237651--Spring-Semester-2024-International-Students-at-Kinugasa-Campus)
  * [I would like to know the necessary procedures for newly entering Japan (Updated 2023/1/10)](/hc/en-us/articles/1500002014102-I-would-like-to-know-the-necessary-procedures-for-newly-entering-Japan-Updated-2023-1-10)
  * [I have received my Certificate of Eligibility (COE) but I have not been able to apply for my visa at the nearest embassy (consulate). Is that okay?](/hc/en-us/articles/360059529993-I-have-received-my-Certificate-of-Eligibility-COE-but-I-have-not-been-able-to-apply-for-my-visa-at-the-nearest-embassy-consulate-Is-that-okay)

## [🛫Procedure when leaving Japan/re-entering Japan](/hc/en-us/sections/360010905994--Procedure-when-leaving-Japan-re-entering-Japan)
  * [If I do plan to leave Japan temporarily, do I need to notify the university?](/hc/en-us/articles/360059530033-If-I-do-plan-to-leave-Japan-temporarily-do-I-need-to-notify-the-university)
  * [If I do plan to leave temporarily Japan, how do I get a Special Re-entry Permission/Re-entry Permission to return to Japan?](/hc/en-us/articles/360059530113-If-I-do-plan-to-leave-temporarily-Japan-how-do-I-get-a-Special-Re-entry-Permission-Re-entry-Permission-to-return-to-Japan)
  * [While I am in my home country temporarily, is it okay NOT to pay for my rent and other fees?](/hc/en-us/articles/360057680274-While-I-am-in-my-home-country-temporarily-is-it-okay-NOT-to-pay-for-my-rent-and-other-fees)

## [💴Tuition Reduction and Payment](/hc/en-us/sections/360012032593--Tuition-Reduction-and-Payment)
  * [I was accepted for a tuition reduction, but I am planning to take a leave of absence. What will happen to my tuition reduction?](/hc/en-us/articles/4411782688787-I-was-accepted-for-a-tuition-reduction-but-I-am-planning-to-take-a-leave-of-absence-What-will-happen-to-my-tuition-reduction)
  * [How do I apply for tuition reduction? (updated 2024/4/12)](/hc/en-us/articles/360059530133-How-do-I-apply-for-tuition-reduction-updated-2024-4-12)
  * [I am currently leaving from Japan, so I am concerned that my tuition payment slip may have been sent to my Japanese address. How can I get the payment slip?](/hc/en-us/articles/360059529293-I-am-currently-leaving-from-Japan-so-I-am-concerned-that-my-tuition-payment-slip-may-have-been-sent-to-my-Japanese-address-How-can-I-get-the-payment-slip)
  * [After paying my tuition, the results of the tuition reduction applications were released and I found out that I overpaid. Can I be refunded?](/hc/en-us/articles/360057680034-After-paying-my-tuition-the-results-of-the-tuition-reduction-applications-were-released-and-I-found-out-that-I-overpaid-Can-I-be-refunded)
  * [The results of tuition reduction have not yet been announced, but I have already received my tuition invoice. Am I allowed to pay tuition after the results have been announced?](/hc/en-us/articles/360057680194-The-results-of-tuition-reduction-have-not-yet-been-announced-but-I-have-already-received-my-tuition-invoice-Am-I-allowed-to-pay-tuition-after-the-results-have-been-announced)
  * [When will we find out the results for tuition reduction?](/hc/en-us/articles/360057680254-When-will-we-find-out-the-results-for-tuition-reduction)

[ See all 7 articles ](/hc/en-us/sections/360012032593--Tuition-Reduction-and-Payment)
## [💴Scholarships and Support Funding](/hc/en-us/sections/360010906034--Scholarships-and-Support-Funding)
  * [Any scholarships international students can apply for individually? （Updated on 2024/3/4）](/hc/en-us/articles/7212441455763-Any-scholarships-international-students-can-apply-for-individually-Updated-on-2024-3-4)
  * [How do I apply for scholarships? (updated 2024/4/2)](/hc/en-us/articles/360057680014-How-do-I-apply-for-scholarships-updated-2024-4-2)
  * [When will the results of the scholarship applications be announced?](/hc/en-us/articles/360057680134-When-will-the-results-of-the-scholarship-applications-be-announced)

## [💡Useful Information for Daily Life](/hc/en-us/sections/360010906074--Useful-Information-for-Daily-Life)
  * [I would like to know events and discounted tickets information for International Students and places to learn Japanese.](/hc/en-us/articles/9961793028115-I-would-like-to-know-events-and-discounted-tickets-information-for-International-Students-and-places-to-learn-Japanese)
  * [I heard that I can talk to the international student support coordinator to talk about my student life. Should I go to the service window?](/hc/en-us/articles/360057679294-I-heard-that-I-can-talk-to-the-international-student-support-coordinator-to-talk-about-my-student-life-Should-I-go-to-the-service-window)
  * [Where can I collect information on living in Japan?](/hc/en-us/articles/360057679534-Where-can-I-collect-information-on-living-in-Japan)
  * [I am feeling uneasy since I am unaccustomed to living in Japan. Are there any help-desks that I can consult?](/hc/en-us/articles/360057679554-I-am-feeling-uneasy-since-I-am-unaccustomed-to-living-in-Japan-Are-there-any-help-desks-that-I-can-consult)
  * [Things that require special attention when living in Japan (updated on 2023/8/31)](/hc/en-us/articles/17115768417043-Things-that-require-special-attention-when-living-in-Japan-updated-on-2023-8-31)
  * [I heard that international students are considered “non-residents” for their first 6 months in Japan, and that they need to be careful with money transfers at the bank. Could you please explain?](/hc/en-us/articles/8307521543827-I-heard-that-international-students-are-considered-non-residents-for-their-first-6-months-in-Japan-and-that-they-need-to-be-careful-with-money-transfers-at-the-bank-Could-you-please-explain)

## [🏠Housing](/hc/en-us/sections/360012032653--Housing)
  * [How do I look for housing in Japan?](/hc/en-us/articles/360057679574-How-do-I-look-for-housing-in-Japan)
  * [Can I live in a university dorm?](/hc/en-us/articles/360059529873-Can-I-live-in-a-university-dorm)

## [👨‍🔧Part-time Jobs (ARUBAITO)](/hc/en-us/sections/360010906094--Part-time-Jobs-ARUBAITO)
  * [What kind of procedure do I have to do in order to do a part-time job?](/hc/en-us/articles/360059529333-What-kind-of-procedure-do-I-have-to-do-in-order-to-do-a-part-time-job)
  * [Are there restrictions on when I am allowed to do a part-time job?](/hc/en-us/articles/360057680054-Are-there-restrictions-on-when-I-am-allowed-to-do-a-part-time-job)

## [👩‍🎓For Alumni/Graduated students ](/hc/en-us/sections/360010906134--For-Alumni-Graduated-students)
  * [Important Procedures When Leaving Japan](/hc/en-us/articles/29811053054227-Important-Procedures-When-Leaving-Japan)
  * [I want to continue job hunting in Japan after graduation. Is it possible to stay in Japan with a “Student” status of residence? (Updated 2024.02.02)](/hc/en-us/articles/4403634978451-I-want-to-continue-job-hunting-in-Japan-after-graduation-Is-it-possible-to-stay-in-Japan-with-a-Student-status-of-residence-Updated-2024-02-02)
  * [I would like to issue a certificates of graduation. However, I'm no longer in Japan, how should I apply?](/hc/en-us/articles/360059528993-I-would-like-to-issue-a-certificates-of-graduation-However-I-m-no-longer-in-Japan-how-should-I-apply)

## [🔰Information for Incoming Students](/hc/en-us/sections/1500000746141--Information-for-Incoming-Students)
  * [For AY2024 April, New International Students](/hc/en-us/articles/26345554523027-For-AY2024-April-New-International-Students)
  * [For AY2023 September, New International Students](/hc/en-us/articles/19859705093139-For-AY2023-September-New-International-Students)

## [🔰Information for SKP students](/hc/en-us/sections/8202479928211--Information-for-SKP-students)
  * [【SKP】 Application Guidelines FAQ](/hc/en-us/articles/25857686295699--SKP-Application-Guidelines-FAQ)
  * [FAQ on Pre-Arrival Procedures for SKP Students](/hc/en-us/articles/24224397386899-FAQ-on-Pre-Arrival-Procedures-for-SKP-Students)
  * [【2024 Spring semester 】 Course Registeration FAQ](/hc/en-us/articles/19893224344851--2024-Spring-semester-Course-Registeration-FAQ)

