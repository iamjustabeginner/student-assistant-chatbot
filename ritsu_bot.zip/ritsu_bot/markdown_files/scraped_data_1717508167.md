For study abroad programs offered by the International Center, participants
are required to purchase an overseas travel insurance and register for risk
management services (24-hour phone support and safety confirmation system).
This provides a system to quickly respond to incidents/ accidents that occur
while studying abroad.

*For inquiries, please contact the study abroad staff at the International Center [＜Here＞](https://global.support.ritsumei.ac.jp/hc/en/requests/new?ticket_form_id=360006493753).

