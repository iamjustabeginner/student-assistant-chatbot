Items included in the program fee are described in the “Application
Guidelines” for each study abroad program. Please check these carefully as the
items for each program will differ.

For details, please check “Application Guidelines” page posted on the Study
Abroad Programs website.

Application Guidelines:
<https://secure.ritsumei.ac.jp/students/studyabroad/students/guideline.html/>

*For inquiries, please contact the study abroad staff at the International Center [＜Here＞](https://global.support.ritsumei.ac.jp/hc/en/requests/new?ticket_form_id=360006493753).

