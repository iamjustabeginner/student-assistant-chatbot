The country or region (state) of destination may require specific vaccinations
for study abroad students. In this case, you must be vaccinated before
traveling.

Even if vaccination is not required, it may be recommended to prevent the
spread of infectious diseases (on a voluntary basis).  
In addition, there is a Travel Clinic in the Medical Service Center on each of
RU’s campuses where you can get vaccinated. For details, please contact the
Medical Service Center Travel Clinic.

Email: hokenask@st.ritsumei.ac.jp  
[Kinugasa Campus] Shigakukan 1F TEL:O75-465-8232  
[Biwako Kusatsu Campus (BKC)] West Wing 1F TEL:077-561-2635  
[Osaka Ibaraki Campus (OIC)] AS 1F TEL:072-665-2110

