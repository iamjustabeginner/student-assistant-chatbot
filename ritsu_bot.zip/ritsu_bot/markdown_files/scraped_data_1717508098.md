Please be aware that even if you are away from Japan for a long period of
time, you must continue to pay fees for your housing, mobile phone,
electricity and city gas if you do not undergo the cancellation process.

If you would like to change your payment method or avoid paying, please
consult the company managing your residence or the appropriate help desk.

