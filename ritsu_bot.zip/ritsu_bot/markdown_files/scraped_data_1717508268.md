# Information for International Students

International Center has opened the following web pages to enable
international students to obtain necessary information and ask questions or
consultation. Important information will also be communicated via manaba+R and
e-mail.

####  International Center Online Support Desk (FAQ, Inquiry Form)

Frequently asked questions (FAQ) from international students and a form for
submitting questions and concerns are available.

<https://global.support.ritsumei.ac.jp/hc/en-us>

#### The website of International Center

The website includes the necessary information for living in Japan such as the
application for scholarships and National Health Insurance, etc.

<https://en.ritsumei.ac.jp/current-students/>

#### Application Form for Individual Consultation with the International
Student Support Coordinator (ISSC)

There are international student support coordinators at International Center
who is available to provide consultation on daily life for international
students. If you would like to talk with them, please apply for a reservation
using the application form below.

Please click [here](https://forms.office.com/Pages/ResponsePage.aspx?id=jUNJpAY2C0mET8ThXlNfyjAJxxYEO0hJvJKlb5fDE3ZURTFRVTE0U1U5WlUxN0MxNklFWllUQkRaQy4u) or read the QR code below.
**For inquiries**  
International Center Kinugasa: Meigakukan 1F  
BKC: Central Arc 2F  
OIC：Building A 1F AN Administrative Office  

