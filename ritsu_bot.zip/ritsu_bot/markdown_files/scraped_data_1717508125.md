Students are chosen for tuition reduction based on their academic performance
and if they hold the "student (留学)" resident status. For details, please check
the application guidelines which are released around the application period
(Early April/Late September).

To inquire about this matter, please contact the International Center, Scholarship Desk at [rscholar@st.ritsumei.ac.jp](mailto:rscholar@st.ritsumei.ac.jp).

