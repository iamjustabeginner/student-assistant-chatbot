GPA requirements vary depending on the study abroad program. For details,
please check the application guidelines for each program.

Even if the program does not set a GPA standard as an application requirement,
it will be an evaluation item in the selection process, so please be diligent
in your studies everyday.

*For inquiries, please contact the study abroad staff at the International Center [＜Here＞](https://global.support.ritsumei.ac.jp/hc/en/requests/new?ticket_form_id=360006493753).

